package com.legend.delivery;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
